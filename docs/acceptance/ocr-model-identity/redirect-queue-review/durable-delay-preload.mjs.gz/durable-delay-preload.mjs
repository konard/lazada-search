import assert from 'node:assert/strict';
import { setTimeout as pause } from 'node:timers/promises';
import { AssociativeStore } from '../../../../src/store.js';
import { DomainScheduler } from '../../../../src/cache.js';
import { sha256 } from '../../../../src/util.js';

const delayed = new WeakSet();
const originalPut = AssociativeStore.prototype.put;
AssociativeStore.prototype.put = async function (kind, record) {
  const result = await originalPut.call(this, kind, record);
  const scenario =
    record.initialUrl === 'https://cdn.example/original.png'
      ? 'same-host'
      : record.initialUrl === 'https://a.example/0.png' &&
          record.url === record.initialUrl &&
          record.locationSha256 === sha256('https://a.example/1.png')
        ? 'six-hop-limit'
        : undefined;
  if (kind === 'image-source-hop' && scenario && !delayed.has(this)) {
    delayed.add(this);
    assert.deepEqual(await this.get(kind, result.id), result);
    assert.equal(sha256(await this.blob(result.blob.sha256)), result.sourceSha256);
    const started = performance.now();
    await pause(3500);
    const elapsedMs = performance.now() - started;
    assert.ok(elapsedMs > 3000);
    console.log(
      `durable-delay-proof ${JSON.stringify({ scenario, delayMs: 3500, elapsedMs, originalSha256: result.sourceSha256, durableOriginalVerified: true })}`
    );
  }
  return result;
};

const originalRun = DomainScheduler.prototype.run;
DomainScheduler.prototype.run = function (url, action) {
  if (
    url === 'https://a.example/source.png' ||
    url === 'https://a.example/target.png' ||
    url === 'https://b.example/target.png'
  ) {
    console.log(`underlying-scheduler-proof ${JSON.stringify({ url })}`);
  }
  return originalRun.call(this, url, action);
};
