import { randomUUID } from 'node:crypto';
export const moduleStamp=randomUUID();
if(globalThis.__parallelSharedModule!==undefined)throw new Error('Module global leaked across files');
globalThis.__parallelSharedModule=moduleStamp;
