import {test,expect} from 'bun:test';
import {writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {moduleStamp} from './shared.js';
const index=2;
test(`native parallel file ${index} is complete and isolated`,async()=>{
 expect(globalThis.__parallelFileSentinel).toBeUndefined();
 globalThis.__parallelFileSentinel=index;
 const event={index,pid:process.pid,moduleStamp,startedAt:Date.now()};
 const target=join(process.env.PARALLEL_PROOF_EVENTS,`${index}.json`);
 writeFileSync(target,JSON.stringify(event));
 await new Promise(resolve=>setTimeout(resolve,300));
 event.finishedAt=Date.now();
 event.expectedFailure=process.env.PARALLEL_PROOF_FAILURE==='1'&&index===1;
 writeFileSync(target,JSON.stringify(event));
 expect(event.expectedFailure).toBe(false);
});
