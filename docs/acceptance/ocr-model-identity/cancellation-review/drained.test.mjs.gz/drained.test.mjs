import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, access, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { AssociativeStore, LazadaSearch } from "file:///Users/konard/Code/Archive/konard/lazada-search/src/index.js";
const mode = "drained";
const controller = new AbortController();
const events = [];
const event = (name, details = {}) => {
  events.push({name, ...details});
  console.log('CANCELLATION-PROOF', JSON.stringify(events.at(-1)));
};
let importPromise, directory, producerFinished = false;
const exists = async(path) => { try { await access(path); return true; } catch { return false; } };
test(`synthetic durable import remains cancelled with ${mode} cleanup`, {signal:controller.signal}, async(t) => {
  directory = await mkdtemp(join(tmpdir(), 'lazada-cancellation-proof-'));
  const store = new AssociativeStore({directory});
  const app = new LazadaSearch({store,offline:true,ocr:false});
  app.collector.start = () => {throw new Error('Synthetic cancellation must never start a browser');};
  t.after(async()=>{
    event('cleanup-start', {producerFinished});
    if(mode === 'drained') await importPromise?.catch(()=>undefined);
    event('cleanup-before-rm', {producerFinished, directoryExists:await exists(directory)});
    if(mode === 'drained') assert.equal(producerFinished,true);
    await app.close();
    await rm(directory,{recursive:true,force:true});
    event('cleanup-removed', {producerFinished});
  });
  const fixture = JSON.parse(await readFile("/Users/konard/Code/Archive/konard/lazada-search/tests/fixtures/products.json",'utf8'));
  const product = {...fixture.products[0],id:'synthetic-cancel-product'};
  const realPutMany=store.putMany.bind(store);
  store.putMany=async(kind,records)=>{
    const result=await realPutMany(kind,records);
    if(kind === 'discovery') {
      const recordPath=store.recordPath('discovery','synthetic-cancel-discovery');
      for(const path of [recordPath,recordPath.replace(/\.lino$/u,'.links'),`${recordPath}.sha256`])assert.equal(await exists(path),true);
      event('durable-originals-exist', {canonical:true,binary:true,digest:true});
      const release = new Promise(resolve=>{
        setTimeout(()=>{
          event('abort-signal', {producerFinished});
          controller.abort(new Error('Synthetic AbortController cancellation after durable import'));
          setTimeout(async()=>{
            event('producer-before-release',{producerFinished,directoryExists:await exists(directory)});
            producerFinished=true;
            event('producer-finished');
            resolve();
          },120);
        },0);
      });
      await release;
    }
    return result;
  };
  importPromise=app.importRecords({products:[product],discoveries:[{id:'synthetic-cancel-discovery',title:'Synthetic cached chocolate whey',url:product.url}]});
  await importPromise;
  if(t.signal.aborted) { event('cancelled-body-stopped'); return; }
  event('post-import-audit-start');
  await app.audit();
});
process.once('beforeExit',async()=>{
  const summary={mode,events,syntheticFixture:true,fullCatalogAcceptance:false,productDownloads:0};
  await writeFile("/Users/konard/Code/Archive/konard/lazada-search/.lazada-search/drafts/ocr-model-identity/cancellation-review/drained-events.json",JSON.stringify(summary,null,2)+'\n');
});
