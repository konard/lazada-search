import json,gzip,hashlib
from pathlib import Path
from datetime import datetime,timezone
out=Path('docs/acceptance/ocr-model-identity')
r=json.loads((out/'ci-ad1be26-review.json').read_text())
assert r['sourceCommit']=='ad1be2636c2c7b91b471e32b0d6842f98630e2a7'
assert r['allNineMatrixJobsPassed'] and r['matrixJobsPassed']==9 and r['matrixJobsFailed']==0 and not r['matrixJobsPending']
assert len(r['results'])==10
for x in r['results']:
 assert x['conclusion']=='success'
 c=x['counts']
 assert all(c.get(k,0)==0 for k in ['fail','failed','failedSteps','skip','skipped','cancelled'])
 assert not c.get('budgetExceeded')
assert r['nativeE2e']['tests']==r['nativeE2e']['pass']==48
assert r['offlineLinks']['counts']['errors']==0
now=datetime.now(timezone.utc).isoformat()
receipt='../ocr-model-identity/ci-ad1be26-review.json'
issuefile=Path('docs/acceptance/requirements-audit/github-issues.json')
issues=json.loads(issuefile.read_text())
openissues=[i['number'] for i in issues if i['state']!='CLOSED']
current={
 'sourceCommit':r['sourceCommit'],'receipt':receipt,'runtimeJobsExecuted':9,'matrixJobsPassed':9,'matrixJobsFailed':0,'matrixJobsPending':[],'allNineAccepted':True,
 'nativeBrowserE2ePassed':48,'nativeBrowserE2eFailures':0,'nativeBrowserE2eCancellations':0,'nativeBrowserE2eSkips':0,'nativeBrowserE2eRun':r['nativeE2eRun'],
 'WindowsNodeAccepted':True,'WindowsDenoAccepted':True,'failedRuntimeJobs':[],'remainingFailure':None,
 'psCorrection':'../ocr-model-identity/release-ps-validation.json',
 'WindowsFilesystemFollowup':'Actual complete ad1be26 matrix accepts bounded prepared directories and successful temporary rename cleanup without changing original fixtures, fsync, worker limits or deadlines.',
 'openIssues':openissues,'allRequirementsDelivered':False,'allTargetProductsCollected':False,'productionReady':False,'purchaseReady':False,'collectionStopActive':True,'productDownloads':0
}
paths=[Path('docs/acceptance/requirements-audit/implementation-updates.json'),Path('docs/acceptance/source-integrity/remaining-work.json')]
u=json.loads(paths[0].read_text());s=json.loads(paths[1].read_text())
# Retain every dated rejection instead of overwriting its history.
u.setdefault('historicalRuntimeCheckpoint7e47c37',u['latestRuntimeCheckpoint'])
s.setdefault('historicalRuntimeAcceptance7e47c37',s['latestRuntimeAcceptance'])
s.setdefault('historicalRemotePlatformAcceptance7e47c37',s['currentRemotePlatformAcceptance'])
u['latestRuntimeCheckpoint']=current
s['latestRuntimeAcceptance']={**current,'fullRuntimeJobsPassed':9}
s['currentRemotePlatformAcceptance']={'sourceCommit':r['sourceCommit'],'evidence':receipt,'runtimeJobsExecuted':9,'matrixJobsPassed':9,'matrixJobsFailed':0,'matrixJobsPending':[],'allNineMatrixJobsPassed':True,'nativeE2e':r['nativeE2e'],'failedRuntimeJobs':[],'remainingFailure':None,'WindowsNodeAccepted':True,'WindowsDenoAccepted':True,'productDownloads':0}
for d,key in [(u,'latestDependencyCheckpoint'),(s,'latestDependencyUpdate')]:
 v=d[key]
 for k in ['actualNewPlatformAcceptancePending','actualCompleteNewMatrixPending']:
  if k in v:v[k]=False
 for k in ['fullNativeBrowserCiSource','actualNativeBrowserCiSource']:
  if k in v:v[k]=r['sourceCommit']
 for k in ['fullNativeBrowserCiRun','actualNativeBrowserCiRun']:
  if k in v:v[k]=r['nativeE2eRun']
 v['currentRuntimeMatrixReceipt']=receipt;v['currentRuntimeMatrixJobsPassed']=9;v['currentRuntimeMatrixJobsFailed']=0
for d in [u,s]:
 d['checkedAt']=now
 for key in ['latestReleaseChildFollowup','latestReleasePsFollowup','latestLocalReleasePsAcceptance','latestCatalogIOFollowup']:
  if key not in d:continue
  v=d[key];v['freshCompletePlatformAcceptancePending']=False;v['actualCompletePlatformReceipt']=receipt;v['actualCompletePlatformSource']=r['sourceCommit'];v['actualCompletePlatformJobsPassed']=9;v['actualNativeBrowserE2ePassed']=48
  if 'status' in v:v['status']='focused-and-full-local-plus-actual-nine-runtime-and-native-browser-accepted'
 for key in ['allRequirementsDelivered','allTargetProductsCollected','productionReady','purchaseReady']:
  if key in d:d[key]=False
 if 'collectionStopActive' in d:d['collectionStopActive']=True
rows={x['id']:x for x in u['requirements']+u['additionalRequirements']}
newpath='docs/acceptance/ocr-model-identity/ci-ad1be26-review.json'
for id in ['R004','R033','R036','R048','R049']:
 row=rows[id]
 if newpath not in row['evidence']:row['evidence'].append(newpath)
rows['R004']['finding']='Complete observed chocolate/no-shaker SKU combinations replace incompatible generic defaults before saving a price. Live Scitec Socola/Không Bình original verification is retained. Fresh CLI/case and Telegram options default to chocolate-or-unflavoured with paid-shaker exclusions, and explicit broad overrides remain supported. Actual sourcead1be26 passes all nine complete runtime suites and48 native/browser cases without failures, cancellations or skips. Historical failures remain preserved; no current stock, complete inventory or delivered winner is inferred.'
rows['R033']['realDataAcceptance']='installed-0.31.1-shared-notation-0.25.2-actual-nine-runtime-and48-native-browser-accepted'
rows['R033']['finding']='Official Browser Commander0.31.1 and shared root Links Notation0.25.2 remain installed with reviewed archive/registry integrity and audit0. Actual sourcead1be26 accepts all nine complete runtime jobs and48/48 native/browser cases. Owned-process ps inspection avoids protected /proc reads while preserving scoped frozen Deno permissions and its failure control. All original catalog fixtures, durable writes and deadlines remain intact. Historical failed runs remain preserved. No collection resume or unmatched factory-data approval is inferred.'
rows['R036']['finding']='Committed sourcead1be26 contains code, tests, public cached case, reports and original local validation logs. Actual GitHub CI observes that source with all nine runtime suites and48 native/browser cases accepted. Full34,253-record/7,030-blob public archive verifies with zero downloads, and final825 local executable/dependency hashes remain unchanged. Actual new CI originals are preserved in the source-specific receipt; private authentication/profile/checkout sources stay local.'
rows['R048']['status']='implemented'
rows['R048']['realDataAcceptance']='accepted-actual-nine-runtime-and48-native-browser-model-and-recipe-proofs'
rows['R048']['finding']='Actual sourcead1be26 accepts all nine complete Node/Bun/Deno runtime suites on Ubuntu/macOS/Windows and48/48 native/browser cases, without failures, cancellations or skips. Literal source-pixel4.5/4.0 recovery, trained-model-byte identity, same-path replacement invalidation, restarted original-TSV cache reuse and failure guards remain exercised. Frozen local proof binds825 files; full original catalog fixtures,450-second test/600-second suite deadlines and scoped Deno permissions remain unchanged. Historical decimal, process, format and catalog failures are preserved. No unmatched marketplace nutrition is approved.'
rows['R049']['realDataAcceptance']='accepted-actual-offline-workflow-38163139368-zero-errors'
rows['R049']['finding']=f"Actual sourcead1be26 offline publication parsed{r['offlineLinks']['counts']['total']} links: {r['offlineLinks']['counts']['successful']} local successes,{r['offlineLinks']['counts']['excluded']} excluded,zero errors, without external probes. Original sources retain archive digest checks. All-nine runtime and48 native/browser acceptance do not establish current market completeness or external URL liveness."
s['remainingEngineering']=[x for x in s['remainingEngineering'] if not x.startswith('Complete actual nine-runtime acceptance')]
s['remainingValidationAcceptance']=[x for x in s['remainingValidationAcceptance'] if not x.startswith('Fresh final-source complete nine-runtime')]
s['remainingIssues']=openissues
s.setdefault('historicalCatalogPerformanceEvidenceSource99',s['catalogPerformanceEvidence'])
s['catalogPerformanceEvidence']={'sourceCommit':r['sourceCommit'],'evidence':receipt,'scope':'Actual full catalog phase receipts in each complete runtime job; no guaranteed latency for future hosts.','Windows':[{k:x[k] for k in ['runtime','counts','catalogPhases','catalogFixtures','originalSha256']} for x in r['results'] if x['platform']=='windows'],'finding':'All three Windows suites complete within unchanged450-second catalog and600-second suite budgets after bounded directory preparation and successful-temp cleanup. Exact original records, writer bounds, chronology, file sync, directory sync and renames remain required. All failed earlier originals are preserved.'}
s['latestDraftFrozenCode']='../ocr-model-identity/catalog-io-frozen-code.json'
s['acceptedFrozenCode']='../ocr-model-identity/catalog-io-frozen-code.json'
s['offlinePublicationPolicyAcceptance']={'sourceCommit':r['sourceCommit'],'workflow':r['offlineLinks']['workflow'],'conclusion':r['offlineLinks']['conclusion'],'localLinksPassed':r['offlineLinks']['counts']['successful'],'totalLinks':r['offlineLinks']['counts']['total'],'excludedLinks':r['offlineLinks']['counts']['excluded'],'errors':0,'externalURLLivenessAttested':False,'evidence':receipt}
for p,d in zip(paths,[u,s]):p.write_text(json.dumps(d,indent=2)+'\n')
p=out/'catalog-io-publication.json';d=json.loads(p.read_text());d['freshFullPlatformAcceptancePending']=False;d['actualCompletePlatformReceipt']='ci-ad1be26-review.json';d['actualRuntimeJobsPassed']=9;d['actualNativeBrowserTestsPassed']=48;d['actualOfflineLocalLinksPassed']=r['offlineLinks']['counts']['successful'];p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'updated':[str(p) for p in paths],'actualSource':r['sourceCommit'],'openIssues':openissues,'allRequirementsDelivered':False,'collectionStopActive':True,'productDownloads':0}))
