import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
function processCanWrite(pid) {
  try {
    process.kill(pid, 0);
  } catch (error) {
    if (error.code === 'ESRCH') {
      return false;
    }
    throw error;
  }
  if (process.platform === 'win32') {
    return true;
  }
  const state = spawnSync('ps', ['-o', 'stat=', '-p', String(pid)], {
    encoding: 'utf8',
  });
  if (state.error) {
    throw state.error;
  }
  if (state.status === 1 && !state.stdout.trim() && !state.stderr.trim()) {
    return false;
  }
  assert.equal(state.status, 0, `Owned process state failed: ${state.stderr}`);
  assert.equal(state.signal, null);
  assert.equal(state.stderr.trim(), '');
  const value = state.stdout.trim();
  assert.match(value, /^[A-Za-z][A-Za-z0-9+<]*$/);
  return !value.startsWith('Z');
}

assert.equal(processCanWrite(process.pid),true);
const originalPath=process.env.PATH;
let failure;
try{
 process.env.PATH='';
 assert.throws(()=>processCanWrite(process.pid),error=>{failure=error;return error.code==='ENOENT';});
}finally{process.env.PATH=originalPath;}
console.log(JSON.stringify({actualNode:process.version,platform:process.platform,ownedPid:process.pid,actualPsLiveStateVerified:true,actualMissingPsThrows:true,errorCode:failure.code,helperSha256:createHash('sha256').update(processCanWrite.toString()).digest('hex'),fixture:'Original helper source extracted unchanged; actual ps for only this process, then empty private-process PATH produces genuine spawn ENOENT; no mocks or marketplace data.'}));
