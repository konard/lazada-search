import json,re,gzip,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
prefix=sys.argv[1]
root=Path('.lazada-search/drafts/ocr-model-identity'); out=Path('docs/acceptance/ocr-model-identity'); out.mkdir(exist_ok=True)
meta=json.loads((root/f'ci-{prefix}-matrix-jobs.json').read_text()); native=json.loads((root/f'ci-{prefix}-native-jobs.json').read_text()); links=json.loads((root/f'ci-{prefix}-links-jobs.json').read_text())
ansi=re.compile(r'\x1b\[[0-9;]*m')
def save(name):
 p=root/name; raw=p.read_bytes(); packed=gzip.compress(raw,mtime=0); (out/(name+'.gz')).write_bytes(packed)
 return {'log':name+'.gz','originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'gzipSha256':hashlib.sha256(packed).hexdigest()}
def counts(s,runtime):
 if 'did not finish within its 600s budget' in s:
  return {'fullSuiteFooterPresent':False,'budgetExceeded':True,'suiteBudgetSeconds':600,'exitCode':124,'accepted':False}
 if runtime=='deno':
  m=re.findall(r'(?:ok|FAILED) \| (\d+) passed(?: \((\d+) steps?\))? \| (\d+) failed(?: \((\d+) steps?\))?',s)
  assert m, 'Missing complete Deno footer'
  passed,steps,failed,failed_steps=m[-1]
  return {'passed':int(passed),'steps':int(steps or 0),'failed':int(failed),'failedSteps':int(failed_steps or 0)}
 if runtime=='bun':
  d={key:int(re.findall(r'\b(\d+) '+key+r'\b',s)[-1]) for key in ['pass','fail']}; m=re.findall(r'Ran (\d+) tests across (\d+) files\. \[([\d.]+)([sm])\]',s)
  assert m, 'Missing complete Bun footer'
  t,f,sec,unit=m[-1]; d.update(tests=int(t),files=int(f),seconds=float(sec)*(60 if unit=='m' else 1))
  skips=re.findall(r'\b(\d+) skip\b',s)
  if skips:d['skip']=int(skips[-1])
  return d
 d={key:float(value) if '.' in value else int(value) for key,value in re.findall(r'(?:# |ℹ )(tests|pass|fail|cancelled|skipped|duration_ms) ([\d.]+)',s)}
 assert set(['tests','pass','fail','cancelled','skipped']).issubset(d), 'Missing complete Node/native footer'
 return d
results=[]
matrix_jobs=[j for j in meta['jobs'] if j['name'].startswith('Test (')]
assert len(matrix_jobs)==9, 'Exactly nine runtime matrix jobs required'
assert native['headSha']==meta['headSha']==links['headSha'], 'Original CI checkout identities disagree'
for j in meta['jobs']:
 m=re.fullmatch(r'Test \((\w+) on (\w+)-[\d.]+\)',j['name'])
 if not m:continue
 if j['status']!='completed':continue
 assert j['conclusion'] not in ['skipped','cancelled'], 'Skipped/cancelled runtime is not completed acceptance'
 runtime,platform=m.groups(); name=f'ci-{prefix}-{runtime}-{platform}.log'; s=ansi.sub('',(root/name).read_text())
 d={'runtime':runtime,'platform':platform,'jobId':j['databaseId'],'conclusion':j['conclusion'],'url':f"{meta['url']}/job/{j['databaseId']}",'counts':counts(s,runtime),'catalogPhases':[json.loads(x) for x in re.findall(r'Committed catalog phase: (\{[^\n]+\})',s)],'catalogFixtures':[json.loads(x) for x in re.findall(r'Committed catalog fixture: (\{[^\n]+\})',s)],**save(name)}
 if runtime=='deno' and platform=='ubuntu' and j['conclusion']=='failure' and prefix=='7e47c37':d['observedFailure']='Owned formatter grandchild state check read protected /proc/3290/stat; scoped Deno NotCapable. Only this new test failed; no --allow-all or suppression accepted.'
 if runtime=='bun' and platform=='windows' and j['conclusion']=='failure':d['observedFailure']='Two3000ms redirect watchdog failures' if prefix=='e63df14' else 'Release-format child subprocess exceeded its separate20000ms spawnSync timeout' if prefix=='3821770' else 'Full committed catalog import hit450000ms test deadline' if prefix=='7e47c37' else 'See exact original failed tests';d['failedTests']=list(dict.fromkeys(re.findall(r'\(fail\) ([^\n]+)',s)))
 results.append(d)
s=ansi.sub('',(root/f'ci-{prefix}-native-e2e.log').read_text()); nj=next(j for j in native['jobs'] if j['databaseId']==114518054727) if prefix=='e63df14' else next(j for j in native['jobs'] if j['name']=='Browser, OCR, CLI, Telegram and binary store')
results.append({'runtime':'native-e2e','platform':'ubuntu','jobId':nj['databaseId'],'conclusion':nj['conclusion'],'url':f"{native['url']}/job/{nj['databaseId']}",'counts':counts(s,'node'),**save(f'ci-{prefix}-native-e2e.log')})
ls=ansi.sub('',(root/f'ci-{prefix}-offline-links.log').read_text()); lc={}
for k in ['Total','Successful','Excluded','Errors']:
 m=re.findall(k+r'\s*\|\s*(\d+)',ls); assert m, f'missing{k}'; lc[k.lower()]=int(m[-1])
receipt={'checkedAt':datetime.now(timezone.utc).isoformat(),'sourceCommit':meta['headSha'],'matrixRun':meta['url'],'nativeE2eRun':native['url'],'allNineMatrixJobsPassed':all(j['conclusion']=='success' for j in meta['jobs'] if j['name'].startswith('Test (')),'matrixJobsPassed':sum(j['conclusion']=='success' for j in meta['jobs'] if j['name'].startswith('Test (')),'matrixJobsFailed':sum(j['conclusion']=='failure' for j in meta['jobs'] if j['name'].startswith('Test (')),'matrixJobsPending':[{'name':j['name'],'jobId':j['databaseId'],'status':j['status']} for j in matrix_jobs if j['status']!='completed'],'remainingFailure':None if all(j['conclusion']=='success' for j in meta['jobs'] if j['name'].startswith('Test (')) else 'See exact original failed job counts and logs; full matrix is not accepted.','WindowsNodeAccepted':any(j['runtime']=='node' and j['platform']=='windows' and j['conclusion']=='success' and j['counts'].get('fail',1)==0 and j['counts'].get('cancelled',1)==0 and j['counts'].get('skipped',1)==0 for j in results),'WindowsDenoAccepted':any(j['runtime']=='deno' and j['platform']=='windows' and j['conclusion']=='success' and j['counts'].get('failed',1)==0 for j in results),'nativeE2e':results[-1]['counts'],'releasePreflight':'Failed separately on package-owner npm publisher configuration; mandatory guard retained under issue32.','results':results,'offlineLinks':{'workflow':links['url'],'conclusion':links['conclusion'],'counts':lc,'externalURLLivenessAttested':False,**save(f'ci-{prefix}-offline-links.log')},'originalMetadata':[save(f'ci-{prefix}-{suffix}-jobs.json') for suffix in ['matrix','native','links']],'productDownloads':0,'allRequirementsDelivered':False,'productionReady':False,'collectionStopActive':True,'frozenExecutableSnapshot':'release-child-frozen-code.json' if prefix=='7e47c37' else 'catalog-io-frozen-code.json' if prefix not in ['d46a7d7','3821770','e63df14'] else 'browser-commander-0311-frozen-code.json' if prefix=='d46a7d7' else 'redirect-frozen-code.json' if prefix=='3821770' else 'e63df14-frozen-code.json'}
(out/f'ci-{prefix}-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'matrixJobsPassed':receipt['matrixJobsPassed'],'matrixJobsFailed':receipt['matrixJobsFailed'],'results':[{k:v for k,v in x.items() if k in ['runtime','platform','counts']} for x in results],'links':lc},indent=2))
