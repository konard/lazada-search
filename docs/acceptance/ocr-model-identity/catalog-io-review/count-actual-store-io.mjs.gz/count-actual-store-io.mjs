import fs from 'node:fs/promises';
import { syncBuiltinESMExports } from 'node:module';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
const original = Object.fromEntries(['mkdir','rm','open','rename'].map(name => [name,fs[name]]));
const calls = [];
for (const name of ['mkdir','rm','rename']) {
  fs[name] = async (...args) => {
    calls.push({operation:name,path:String(args[0])});
    return original[name](...args);
  };
}
fs.open = async (...args) => {
  const handle = await original.open(...args);
  const sync = handle.sync.bind(handle);
  handle.sync = async () => {
    calls.push({operation:'sync',path:String(args[0])});
    return sync();
  };
  return handle;
};
syncBuiltinESMExports();
const { AssociativeStore } = await import(pathToFileURL(resolve('src/store.js')).href);
const fixturePath = resolve('docs/tables/catalog.json');
const fixtureBytes = await fs.readFile(fixturePath);
const records = JSON.parse(fixtureBytes).discoveries.slice(0,96);
const directory = await fs.mkdtemp(join(tmpdir(),'lazada-actual-io-count-'));
const store = new AssociativeStore({directory:join(directory,'store')});
const started = performance.now();
try {
  await store.putMany('discovery',records);
  const actual=(await store.list('discovery')).length;
  if(actual !== records.length)throw new Error('Actual durable record count mismatch');
  const kindPath=join(store.directory,'discovery');
  console.log(JSON.stringify({scope:'Actual unchanged-code durable writes of first96originaldiscovery records, diagnostic sample not whole-catalog acceptance',runtime:process.version,platform:process.platform,sourceFixtureSha256:createHash('sha256').update(fixtureBytes).digest('hex'),sourceFixtureBytes:fixtureBytes.length,records:actual,durationMs:performance.now()-started,counts:{kindDirectoryMkdir:calls.filter(c=>c.operation==='mkdir'&&c.path===kindPath).length,temporaryRm:calls.filter(c=>c.operation==='rm'&&c.path.endsWith('.tmp')).length,fileSync:calls.filter(c=>c.operation==='sync'&&c.path.endsWith('.tmp')).length,directorySync:calls.filter(c=>c.operation==='sync'&&!c.path.endsWith('.tmp')).length,rename:calls.filter(c=>c.operation==='rename').length},storeSourceSha256:createHash('sha256').update(await fs.readFile('src/store.js')).digest('hex'),utilSourceSha256:createHash('sha256').update(await fs.readFile('src/util.js')).digest('hex')}));
}finally {
  for(const [name,method] of Object.entries(original)) fs[name]=method;
  syncBuiltinESMExports();
  await fs.rm(directory,{recursive:true,force:true});
}
