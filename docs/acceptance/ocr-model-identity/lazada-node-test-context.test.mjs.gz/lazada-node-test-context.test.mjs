import test from 'node:test';
test('actual runtime cancellation context', (t) => {
  console.log(JSON.stringify({ signalPresent: t.signal !== undefined, aborted: t.signal?.aborted }));
});
