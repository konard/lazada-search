import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, readFileSync, writeFileSync, existsSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
async function runReleaseChild(args, { cwd, env, signal, onStdout } = {}) {
  signal?.throwIfAborted();
  return await new Promise((resolve, reject) => {
    const child = spawn('node', args, {
      cwd,
      env,
      signal,
      killSignal: 'SIGKILL',
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    let failure;
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      stdout += chunk;
      onStdout?.(chunk);
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk;
    });
    child.once('error', (error) => {
      failure = error;
    });
    child.once('close', (exitCode, exitSignal) => {
      const result = { exitCode, exitSignal, stdout, stderr, pid: child.pid };
      if (failure || exitCode !== 0 || exitSignal) {
        const error =
          failure ||
          new Error(
            `Release child exited with ${exitCode}/${exitSignal}\n${stdout}\n${stderr}`
          );
        reject(Object.assign(error, result));
      } else {
        resolve(result);
      }
    });
  });
}

const cwd=mkdtempSync(join(tmpdir(),'release-descendant-proof-'));
const controller=new AbortController();
let descendantPid;
let operation;
const poll=async(predicate)=>{while(!predicate()){await new Promise(resolve=>setTimeout(resolve,5));}};
const grandchild=`const fs=require('node:fs');fs.writeFileSync('grandchild-ready',String(process.pid));const timer=setInterval(()=>{if(fs.existsSync('release-descendant')){fs.writeFileSync('late-descendant-output','actual descendant wrote after parent close');clearInterval(timer);}},5);`;
const parent=`const fs=require('node:fs');require('node:child_process').spawn(process.execPath,['-e',${JSON.stringify(grandchild)}],{stdio:'ignore'});const timer=setInterval(()=>{if(fs.existsSync('grandchild-ready')){process.stdout.write('descendant ready\\n');clearInterval(timer);setInterval(()=>{},1000);}},5);`;
let ready;
const started=new Promise(resolve=>{ready=resolve;});
try{
 operation=runReleaseChild(['-e',parent],{cwd,signal:controller.signal,onStdout:ready});
 await Promise.race([started,operation]);
 descendantPid=Number(readFileSync(join(cwd,'grandchild-ready'),'utf8'));
 controller.abort(new Error('actual parent cancellation'));
 let cancellation;
 await assert.rejects(operation,error=>{cancellation=error;return error.name==='AbortError'&&error.exitSignal==='SIGKILL';});
 assert.throws(()=>process.kill(cancellation.pid,0),{code:'ESRCH'});
 assert.doesNotThrow(()=>process.kill(descendantPid,0));
 writeFileSync(join(cwd,'release-descendant'),'after parent close');
 await poll(()=>existsSync(join(cwd,'late-descendant-output')));
 const late=readFileSync(join(cwd,'late-descendant-output'),'utf8');
 assert.equal(late,'actual descendant wrote after parent close');
 console.log(JSON.stringify({schemaVersion:1,actualNode:process.version,platform:process.platform,fixture:'synthetic actual Node parent and controlled grandchild, no marketplace data',helperSha256:createHash('sha256').update(runReleaseChild.toString()).digest('hex'),parentPid:cancellation.pid,descendantPid,parentExitSignal:cancellation.exitSignal,parentClosedBeforeRelease:true,descendantWroteAfterParentClose:true,output:late}));
}finally{
 controller.abort();
 await operation?.catch(()=>{});
 if(descendantPid){try{process.kill(descendantPid,'SIGKILL');}catch(error){if(error.code!=='ESRCH')throw error;}}
 rmSync(cwd,{recursive:true,force:true});
}
