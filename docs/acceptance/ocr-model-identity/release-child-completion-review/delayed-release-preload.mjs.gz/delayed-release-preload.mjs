import assert from 'node:assert/strict';
import { appendFileSync } from 'node:fs';

const target = (process.argv[1] || '').replaceAll('\\', '/');
if (target.endsWith('/@changesets/cli/bin.js')) {
  const started = performance.now();
  const path = process.env.LAZADA_RELEASE_CHILD_PROOF_LOG;
  const record = (event) =>
    appendFileSync(
      path,
      `${JSON.stringify({ parentRuntime: process.env.LAZADA_RELEASE_CHILD_PARENT_RUNTIME, childNode: process.version, pid: process.pid, target, elapsedMs: performance.now() - started, ...event })}\n`
    );
  record({ event: 'actual-version-child-started', delayMs: 21000 });
  for (const channel of ['stdout', 'stderr']) {
    const write = process[channel].write;
    process[channel].write = function (...args) {
      if (String(args[0]).includes('All files have been updated')) {
        record({ event: 'genuine-changesets-completion-output', channel });
      }
      return write.apply(this, args);
    };
  }
  setTimeout(() => {
    const elapsedMs = performance.now() - started;
    assert.ok(elapsedMs > 20000);
    record({ event: 'artificial-natural-exit-delay-complete', elapsedMs });
  }, 21000);
  process.on('exit', (exitCode) => record({ event: 'actual-child-exited', exitCode }));
}
