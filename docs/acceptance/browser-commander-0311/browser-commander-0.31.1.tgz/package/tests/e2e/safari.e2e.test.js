// feature-parity: safari.control@native-typed
import { it } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import {
  launchRealBrowser,
  SafariUnsupportedError,
  makeBrowserCommander,
} from '../../src/index.js';
import { createDispatcher } from '../../src/cli/dispatcher.js';
import { closeServer } from '../helpers/fixture-server.js';

it(
  'Safari drives a local page in an isolated automation session',
  {
    skip:
      process.platform !== 'darwin' || process.env.RUN_SAFARI_E2E !== 'true',
    timeout: 60_000,
  },
  async () => {
    const server = createServer((_request, response) => {
      response.writeHead(200, { 'content-type': 'text/html' });
      response.end(
        '<title>Safari smoke</title><input id="name"><button id="go" onclick="document.querySelector(\'#out\').textContent=document.querySelector(\'#name\').value">Go</button><p id="out"></p>'
      );
    });
    await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
    const url = `http://127.0.0.1:${server.address().port}/`;
    let session;
    let commander;
    const cli = createDispatcher();
    const phase = (message) =>
      console.info(`[Safari smoke] ${new Date().toISOString()} ${message}`);
    try {
      phase('launch seeded session');
      session = await launchRealBrowser({
        channel: 'safari',
        startupTimeout: 20_000,
        seedCookies: [{ name: 'seed', value: 'yes', url, httpOnly: true }],
      });
      const { page, driver } = session;
      phase('exercise page commands');
      commander = makeBrowserCommander({ page });
      await page.goto(url);
      assert.equal(commander.engine, 'selenium');
      await commander.fill({ selector: '#name', text: 'Safari' });
      await commander.click({ selector: '#go' });
      assert.equal(
        await page.evaluate(() => document.querySelector('#out').textContent),
        'Safari'
      );
      assert.equal(await page.evaluateAsync(async (value) => value + 1, 4), 5);
      assert.ok((await page.screenshot()).length > 100);
      assert.equal((await driver.manage().getCookie('seed')).value, 'yes');
      phase('exercise windows and tabs');
      const initial = await driver.getWindowHandle();
      for (const type of ['tab', 'window']) {
        const handle = await page.newWindow(type);
        assert.ok((await page.windows()).includes(handle));
        await page.goto(url);
        await driver.close();
        await page.switchToWindow(initial);
      }
      await assert.rejects(() => page.pdf(), SafariUnsupportedError);
      await assert.rejects(
        () => page.setRequestInterception(true),
        SafariUnsupportedError
      );
      phase('close seeded session');
      await session.close();
      phase('launch fresh session');
      session = await launchRealBrowser({ channel: 'safari' });
      await session.page.goto(url);
      assert.equal(
        (await session.driver.manage().getCookies()).some(
          (cookie) => cookie.name === 'seed'
        ),
        false
      );
      phase('close fresh session');
      await session.close();
      phase('launch CLI session');
      await cli.dispatch('session.launch', {
        browser: 'safari',
        engine: 'selenium',
      });
      phase('exercise CLI commands');
      await cli.dispatch('page.goto', { url });
      assert.equal(
        (await cli.dispatch('page.eval', { expression: 'document.title' }))
          .value,
        'Safari smoke'
      );
    } finally {
      phase('close CLI session');
      await cli.close();
      phase('destroy commander');
      await commander?.destroy();
      phase('close remaining session and server');
      await session?.close();
      await closeServer(server);
      phase('cleanup complete');
    }
  }
);
