/**
 * Browser Commander - Public API exports
 * This module centralizes all public exports from the browser-commander library.
 */

// Re-export core utilities
export { CHROME_ARGS, TIMING } from './core/constants.js';
export { isVerboseEnabled, createLogger } from './core/logger.js';
export { disableTranslateInPreferences } from './core/preferences.js';
export { detectEngine } from './core/engine-detection.js';
export {
  isNavigationError,
  isTimeoutError,
  safeOperation,
  makeNavigationSafe,
  withNavigationSafety,
} from './core/navigation-safety.js';

// Re-export new core components
export { createNetworkTracker } from './core/network-tracker.js';
export { createNavigationManager } from './core/navigation-manager.js';
export { createPageSessionFactory } from './core/page-session.js';
export { createDialogManager } from './core/dialog-manager.js';

// Re-export engine adapter
export {
  EngineAdapter,
  PlaywrightAdapter,
  PuppeteerAdapter,
  SeleniumAdapter,
  createEngineAdapter,
} from './core/engine-adapter.js';

// Selenium / WebDriver engine (issue #104)
export {
  WebDriverPage,
  WebDriverTimeoutError,
  createWebDriverPage,
  isWebDriver,
} from './core/webdriver-page.js';
export {
  launchWebDriver,
  connectWebDriver,
  resolveWebDriverExecutable,
  CHROMEDRIVER_DEFAULT_SWITCHES,
} from './browser/webdriver.js';

// Page trigger system
export {
  createPageTriggerManager,
  ActionStoppedError,
  isActionStoppedError,
  makeUrlCondition,
  allConditions,
  anyCondition,
  notCondition,
} from './core/page-trigger-manager.js';

// Re-export browser management
export { connectBrowser } from './browser/connector.js';
export {
  listBrowserProfiles,
  listCookieSources,
  readBrowserCookies,
  resolveImportSource,
} from './browser/browser-cookies.js';
export { resolveDefaultBrowser } from './browser/default-browser.js';
export { BROWSER_IDS, findBrowserSource } from './browser/browser-sources.js';
export {
  launchAndConnectRealBrowser,
  launchRealBrowser,
} from './browser/real-browser.js';
export {
  classifyDifferences,
  compareCommandLines,
  measureParity,
  parseSwitches,
  readBrowserVersionPage,
} from './browser/parity.js';
export {
  openInUserBrowser,
  buildOpenCommand,
  validateOpenUrl,
} from './browser/open-in-user-browser.js';
export { migrateProfile, ALL_DATA_CLASSES } from './browser/migration/index.js';
export {
  attachUserBrowser,
  attachViaExtension,
  ATTACH_MODES,
  DEFAULT_RELAY_PORT,
  describeAttachDifferences,
  EXTENSION_DIRECTORY,
  RELAY_PATH,
  snapshotUserDataDir,
} from './browser/attach/index.js';
export {
  launchBrowser,
  LAUNCH_MODES,
  resolveLaunchExecutable,
} from './browser/launcher.js';
export {
  LAUNCH_RESTRICTIONS,
  LAUNCH_RESTRICTION_PRESETS,
  resolveRestrictions,
  mergeFeatureSwitches,
} from './browser/restrictions.js';
export {
  createTemporaryUserDataDir,
  prepareUserDataDir,
  removeUserDataDir,
} from './browser/profile-directory.js';
export {
  PortRaceError,
  reserveLoopbackPort,
} from './browser/debugging-port.js';
export { saveStorageState } from './browser/storage-state.js';
export { emulateMedia } from './browser/media.js';
export {
  waitForUrlStabilization,
  goto,
  setContent,
  waitForNavigation,
  waitForPageReady,
  waitForReady,
  waitAfterAction,
  // Navigation verification
  defaultNavigationVerification,
  verifyNavigation,
} from './browser/navigation.js';

export { pdf } from './browser/pdf.js';

// Re-export element operations
export {
  createPlaywrightLocator,
  getLocatorOrElement,
  waitForLocatorOrElement,
  waitForVisible,
  locator,
} from './elements/locators.js';

export {
  querySelector,
  querySelectorAll,
  findByText,
  normalizeSelector,
  withTextSelectorSupport,
  waitForSelector,
} from './elements/selectors.js';

export { isVisible, isEnabled, count } from './elements/visibility.js';

export {
  content,
  innerText,
  textContent,
  inputValue,
  getAttribute,
  getInputValue,
  logElementInfo,
} from './elements/content.js';

// Re-export interactions
export {
  scrollIntoView,
  needsScrolling,
  scrollIntoViewIfNeeded,
  // Scroll verification
  defaultScrollVerification,
  verifyScroll,
} from './interactions/scroll.js';

export {
  clickElement,
  clickButton,
  // Click verification
  defaultClickVerification,
  capturePreClickState,
  verifyClick,
  // Truthful click result model
  CLICK_STATUS,
  CLICK_EFFECT,
  // Orthogonal activation options
  CLICK_ACTIVATION,
  CLICK_SCROLL,
  CLICK_ACTIONABILITY,
  ScrollConstraintError,
} from './interactions/click.js';

export {
  READINESS_STATUS,
  LONG_LIVED_REQUEST_PATTERNS,
  isLongLivedRequest,
  createDeadline,
  runReadinessChecks,
  // Composable readiness checks
  urlStableFor,
  networkIdleFor,
  domStableFor,
  visibleImages,
  predicate,
  stableCheck,
} from './core/readiness.js';

export {
  checkIfElementEmpty,
  performFill,
  fillTextArea,
  // Fill verification
  defaultFillVerification,
  verifyFill,
} from './interactions/fill.js';

export { pressKey, typeText, keyDown, keyUp } from './interactions/keyboard.js';

// Re-export utilities
export { wait, evaluate, safeEvaluate } from './utilities/wait.js';
export { getUrl, unfocusAddressBar } from './utilities/url.js';

// Re-export high-level universal logic
export {
  waitForUrlCondition,
  installClickListener,
  checkAndClearFlag,
  findToggleButton,
} from './high-level/universal-logic.js';

// Re-export the fingerprint subsystem: parity with a hand-started browser, and
// full control over what a page reads about the environment.
export {
  AUTOMATION_CONTROLLED_OFF_ARG,
  AUTOMATION_CONTROLLED_TRIGGERS,
  ENGINE_PARITY_IGNORED_DEFAULT_ARGS,
  PLAYWRIGHT_HEADLESS_POINTER_ARG,
  PLAYWRIGHT_SOFTWARE_WEBGL_ARG,
  applyAutomationParityArgs,
  detectAutomationControlledTriggers,
  disablesAutomationControlled,
  parityIgnoredDefaultArgs,
} from './fingerprint/automation-parity.js';
export {
  FINGERPRINT_FIELD_MECHANISMS,
  resolveFingerprintProfile,
} from './fingerprint/profile.js';
export { deriveUserAgentData } from './fingerprint/derive.js';
export { buildCdpEmulationCommands } from './fingerprint/cdp-overrides.js';
export {
  buildFingerprintInitScript,
  buildInitScriptConfig,
} from './fingerprint/init-script.js';
export { applyFingerprint } from './fingerprint/apply.js';
// Raw CDP with one surface for both engines (issue #104).
export { createCdpSession, wrapCdpSession } from './browser/cdp-session.js';
export {
  FINGERPRINT_PRESET_NAMES,
  createFingerprintPreset,
} from './fingerprint/presets.js';
export {
  FINGERPRINT_LIMITATIONS,
  findFingerprintLimitation,
  relevantFingerprintLimitations,
} from './fingerprint/limitations.js';

// Re-export the managed download subsystem: one lifecycle for automated and
// manual downloads, with files that outlive the browser (issue #88).
export {
  attachDownloads,
  normalizeDownloadOptions,
} from './downloads/attach.js';
export { DOWNLOAD_EVENT, createDownloadManager } from './downloads/manager.js';
export {
  ARTIFACT_DIRECTORY_MODE,
  ARTIFACT_FILE_MODE,
  DOWNLOAD_DIRECTORY_PRESETS,
  prepareDownloadDirectory,
  resolveDownloadDirectory,
} from './downloads/destination.js';
export {
  DOWNLOAD_CONFLICT,
  cleanPartials,
  saveDownload,
} from './downloads/store.js';
export { DOWNLOAD_FAILURE } from './downloads/sources.js';
export {
  extensionFromContent,
  sanitizeDownloadName,
  withExtension,
} from './downloads/naming.js';

// Re-export the portable trace subsystem: one recorder, one versioned bundle,
// and one offline viewer for every consumer (issue #87).
export { startTrace } from './traces/recorder.js';
export {
  TRACE_EVENT,
  TRACE_EVENT_SOURCES,
  TRACE_FILES,
  TRACE_MODE,
  TRACE_OUTCOME,
  TRACE_SCHEMA_VERSION,
} from './traces/schema.js';
export { diffControlState, parseNdjson, readTrace } from './traces/reader.js';
export { renderTraceViewer, writeTraceViewer } from './traces/viewer.js';
// A Links Notation view of the same bundle, for consumers that keep semantic,
// actor-aware histories of a run (issue #94).
export {
  decodeLinkText,
  encodeLinkText,
  formatTraceLinks,
  traceLinks,
  TRACE_LINK_IDS,
  TRACE_LINK_OUTCOME,
  TRACE_LINKS_FILE,
  TRACE_LINKS_SECTIONS,
  TRACE_LINKS_VERSION,
  writeTraceLinks,
} from './traces/links.js';
export {
  DEFAULT_REDACT_ATTRIBUTES,
  DEFAULT_REDACT_SELECTORS,
  REDACTED,
  normalizePrivacyOptions,
  redactUrl,
  redactValue,
} from './traces/redaction.js';

export {
  SafariSetupError,
  SafariUnsupportedError,
  openSafariSettings,
} from './browser/safari-support.js';

export { BrowserLaunchError } from './browser/launch-diagnostics.js';

export { findFirst, hasText, isChecked, check } from './elements/reusable.js';
export { setCookies, clearCookies } from './browser/session-cookies.js';
export {
  readFlag,
  uninstallClickListener,
} from './high-level/universal-logic.js';

export {
  findSiteSessions,
  readBrowserCookieSession,
} from './browser/browser-cookie-session.js';
