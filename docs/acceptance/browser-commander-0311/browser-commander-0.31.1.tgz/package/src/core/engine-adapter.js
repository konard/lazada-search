/**
 * Engine Adapter - Abstract away Playwright/Puppeteer differences
 *
 * This module implements the Adapter pattern to encapsulate engine-specific
 * logic in a single place, following the "Protected Variations" principle.
 *
 * Benefits:
 * - Eliminates scattered `if (engine === 'playwright')` checks
 * - Easier to add new engines (e.g., Selenium)
 * - Easier to test with mock adapters
 * - Clearer separation of concerns
 */

import { TIMING } from './constants.js';

function notImplemented(methodName) {
  return Promise.reject(
    new Error(`${methodName}() must be implemented by subclass`)
  );
}

/**
 * Base class defining the engine adapter interface
 * All engine-specific operations should be defined here
 */
export class EngineAdapter {
  constructor(page) {
    this.page = page;
  }

  /**
   * Get engine name
   * @returns {string} - 'playwright' or 'puppeteer'
   */
  getEngineName() {
    throw new Error('getEngineName() must be implemented by subclass');
  }

  // ============================================================================
  // Element Selection and Locators
  // ============================================================================

  /**
   * Create a locator/element handle from a selector
   * @param {string} selector - CSS selector
   * @returns {Object} - Locator (Playwright) or ElementHandle (Puppeteer)
   */
  createLocator(_selector) {
    throw new Error('createLocator() must be implemented by subclass');
  }

  /**
   * Query single element
   * @param {string} selector - CSS selector
   * @returns {Promise<Object|null>} - Locator/Element or null
   */
  querySelector(_selector) {
    return notImplemented('querySelector');
  }

  /**
   * Query all elements
   * @param {string} selector - CSS selector
   * @returns {Promise<Array>} - Array of locators/elements
   */
  querySelectorAll(_selector) {
    return notImplemented('querySelectorAll');
  }

  /**
   * Wait for selector to appear
   * @param {string} selector - CSS selector
   * @param {Object} options - Wait options {visible, timeout}
   * @returns {Promise<void>}
   */
  waitForSelector(_selector, _options = {}) {
    return notImplemented('waitForSelector');
  }

  /**
   * Wait for element to be visible
   * @param {Object} locatorOrElement - Locator or element
   * @param {number} timeout - Timeout in ms
   * @returns {Promise<Object>} - The locator/element
   */
  waitForVisible(_locatorOrElement, _timeout = TIMING.DEFAULT_TIMEOUT) {
    return notImplemented('waitForVisible');
  }

  /**
   * Count matching elements
   * @param {string} selector - CSS selector
   * @returns {Promise<number>} - Number of matching elements
   */
  count(_selector) {
    return notImplemented('count');
  }

  // ============================================================================
  // Element Evaluation and Properties
  // ============================================================================

  /**
   * Evaluate function on element
   * @param {Object} locatorOrElement - Locator or element
   * @param {Function} fn - Function to evaluate
   * @param {any} args - Arguments to pass (optional)
   * @returns {Promise<any>} - Result of evaluation
   */
  evaluateOnElement(_locatorOrElement, _fn, _args) {
    return notImplemented('evaluateOnElement');
  }

  /**
   * Get element text content
   * @param {Object} locatorOrElement - Locator or element
   * @returns {Promise<string|null>} - Text content
   */
  getTextContent(_locatorOrElement) {
    return notImplemented('getTextContent');
  }

  /**
   * Get rendered text from an element
   * @param {Object} locatorOrElement - Locator or element
   * @returns {Promise<string>} - Rendered text
   */
  getInnerText(_locatorOrElement) {
    return notImplemented('getInnerText');
  }

  /**
   * Get input value
   * @param {Object} locatorOrElement - Locator or element
   * @returns {Promise<string>} - Input value
   */
  getInputValue(_locatorOrElement) {
    return notImplemented('getInputValue');
  }

  /**
   * Get element attribute
   * @param {Object} locatorOrElement - Locator or element
   * @param {string} attribute - Attribute name
   * @returns {Promise<string|null>} - Attribute value
   */
  getAttribute(_locatorOrElement, _attribute) {
    return notImplemented('getAttribute');
  }

  // ============================================================================
  // Element Interactions
  // ============================================================================

  /**
   * Click element
   * @param {Object} locatorOrElement - Locator or element
   * @param {Object} options - Click options {force, etc.}
   * @returns {Promise<void>}
   */
  click(_locatorOrElement, _options = {}) {
    return notImplemented('click');
  }

  /**
   * Type text into element (simulates typing)
   * @param {Object} locatorOrElement - Locator or element
   * @param {string} text - Text to type
   * @returns {Promise<void>}
   */
  type(_locatorOrElement, _text) {
    return notImplemented('type');
  }

  /**
   * Fill element with text (direct value assignment)
   * @param {Object} locatorOrElement - Locator or element
   * @param {string} text - Text to fill
   * @returns {Promise<void>}
   */
  fill(_locatorOrElement, _text) {
    return notImplemented('fill');
  }

  /**
   * Focus element
   * @param {Object} locatorOrElement - Locator or element
   * @returns {Promise<void>}
   */
  focus(_locatorOrElement) {
    return notImplemented('focus');
  }

  // ============================================================================
  // Page-level Keyboard Operations
  // ============================================================================

  /**
   * Press a key at the page level (e.g. 'Escape', 'Enter', 'Tab')
   * @param {string} key - Key name (Playwright/Puppeteer key format)
   * @returns {Promise<void>}
   */
  keyboardPress(_key) {
    return notImplemented('keyboardPress');
  }

  /**
   * Type text at the page level (dispatches key events for each character)
   * @param {string} text - Text to type
   * @returns {Promise<void>}
   */
  keyboardType(_text) {
    return notImplemented('keyboardType');
  }

  /**
   * Hold a key down at the page level
   * @param {string} key - Key name
   * @returns {Promise<void>}
   */
  keyboardDown(_key) {
    return notImplemented('keyboardDown');
  }

  /**
   * Release a held key at the page level
   * @param {string} key - Key name
   * @returns {Promise<void>}
   */
  keyboardUp(_key) {
    return notImplemented('keyboardUp');
  }

  // ============================================================================
  // Page-level Operations
  // ============================================================================

  /**
   * Evaluate JavaScript in page context
   * @param {Function} fn - Function to evaluate
   * @param {Array} args - Arguments to pass
   * @returns {Promise<any>} - Result of evaluation
   */
  evaluateOnPage(_fn, _args = []) {
    return notImplemented('evaluateOnPage');
  }

  /**
   * Get the full HTML of the current page
   * @returns {Promise<string>} - Serialized page HTML
   */
  getPageContent() {
    return notImplemented('getPageContent');
  }

  /**
   * Get the main frame
   * @returns {Object} - Main frame
   */
  getMainFrame() {
    throw new Error('getMainFrame() must be implemented by subclass');
  }

  /**
   * Generate a PDF of the current page
   * @param {Object} options - PDF options (format, printBackground, margin, etc.)
   * @returns {Promise<Buffer>} - PDF buffer
   */
  pdf(_options = {}) {
    return notImplemented('pdf');
  }
}

/**
 * Playwright adapter implementation
 */
export class PlaywrightAdapter extends EngineAdapter {
  getEngineName() {
    return 'playwright';
  }

  // ============================================================================
  // Element Selection and Locators
  // ============================================================================

  createLocator(selector) {
    // Handle :nth-of-type() pseudo-selectors which don't work in Playwright locators
    const nthOfTypeMatch = selector.match(/^(.+):nth-of-type\((\d+)\)$/);
    if (nthOfTypeMatch) {
      const baseSelector = nthOfTypeMatch[1];
      const index = parseInt(nthOfTypeMatch[2], 10) - 1; // Convert to 0-based
      return this.page.locator(baseSelector).nth(index);
    }
    return this.page.locator(selector);
  }

  async querySelector(selector) {
    const locator = this.createLocator(selector).first();
    const count = await locator.count();
    return count > 0 ? locator : null;
  }

  async querySelectorAll(selector) {
    const locator = this.createLocator(selector);
    const count = await locator.count();
    const elements = [];
    for (let i = 0; i < count; i++) {
      elements.push(locator.nth(i));
    }
    return elements;
  }

  async waitForSelector(selector, options = {}) {
    const { visible = true, timeout = 5000 } = options;
    const locator = this.createLocator(selector);
    await locator.waitFor({ state: visible ? 'visible' : 'attached', timeout });
  }

  async waitForVisible(locatorOrElement, timeout = TIMING.DEFAULT_TIMEOUT) {
    const firstLocator = locatorOrElement.first();
    await firstLocator.waitFor({ state: 'visible', timeout });
    return firstLocator;
  }

  async count(selector) {
    return await this.page.locator(selector).count();
  }

  // ============================================================================
  // Element Evaluation and Properties
  // ============================================================================

  async evaluateOnElement(locatorOrElement, fn, args) {
    // Playwright only accepts a single argument
    if (args === undefined) {
      return await locatorOrElement.evaluate(fn);
    }
    return await locatorOrElement.evaluate(fn, args);
  }

  async getTextContent(locatorOrElement) {
    return await locatorOrElement.textContent();
  }

  async getInnerText(locatorOrElement) {
    return await locatorOrElement.innerText();
  }

  async getInputValue(locatorOrElement) {
    return await locatorOrElement.inputValue();
  }

  async getAttribute(locatorOrElement, attribute) {
    return await locatorOrElement.getAttribute(attribute);
  }

  // ============================================================================
  // Element Interactions
  // ============================================================================

  async click(locatorOrElement, options = {}) {
    await locatorOrElement.click(options);
  }

  async type(locatorOrElement, text) {
    await locatorOrElement.type(text);
  }

  async fill(locatorOrElement, text) {
    await locatorOrElement.fill(text);
  }

  async focus(locatorOrElement) {
    await locatorOrElement.focus();
  }

  // ============================================================================
  // Page-level Keyboard Operations
  // ============================================================================

  async keyboardPress(key) {
    await this.page.keyboard.press(key);
  }

  async keyboardType(text) {
    await this.page.keyboard.type(text);
  }

  async keyboardDown(key) {
    await this.page.keyboard.down(key);
  }

  async keyboardUp(key) {
    await this.page.keyboard.up(key);
  }

  // ============================================================================
  // Page-level Operations
  // ============================================================================

  async evaluateOnPage(fn, args = []) {
    // Playwright only accepts a single argument (can be array/object)
    // To match Puppeteer's behavior where args are spread, we wrap the function
    // and pass all args as a single array, then apply them in the browser context
    if (args.length === 0) {
      return await this.page.evaluate(fn);
    } else if (args.length === 1) {
      return await this.page.evaluate(fn, args[0]);
    } else {
      // Multiple args - wrap function to accept array and spread them
      // This makes Playwright behave like Puppeteer's spread behavior
      // We pass the function string and args array, then reconstruct and call in browser
      const fnString = fn.toString();
      return await this.page.evaluate(
        ({ fnStr, argsArray }) => {
          // Reconstruct the function in browser context and call with spread args
          const reconstructedFn = new Function(`return (${fnStr})`)();
          return reconstructedFn(...argsArray);
        },
        { fnStr: fnString, argsArray: args }
      );
    }
  }

  async getPageContent() {
    return await this.page.content();
  }

  getMainFrame() {
    return this.page.mainFrame();
  }

  async pdf(options = {}) {
    return await this.page.pdf(options);
  }
}

/**
 * Puppeteer adapter implementation
 */
export class PuppeteerAdapter extends EngineAdapter {
  getEngineName() {
    return 'puppeteer';
  }

  // ============================================================================
  // Element Selection and Locators
  // ============================================================================

  createLocator(selector) {
    // Puppeteer doesn't have locators - just returns selector
    // The actual element will be queried when needed
    return selector;
  }

  async querySelector(selector) {
    return await this.page.$(selector);
  }

  async querySelectorAll(selector) {
    return await this.page.$$(selector);
  }

  async waitForSelector(selector, options = {}) {
    const { visible = true, timeout = 5000 } = options;
    await this.page.waitForSelector(selector, { visible, timeout });
  }

  waitForVisible(locatorOrElement, _timeout = TIMING.DEFAULT_TIMEOUT) {
    // For Puppeteer, locatorOrElement is already an ElementHandle
    // We can't wait on it directly, so we just return it
    // The caller should have already used waitForSelector
    return locatorOrElement;
  }

  async count(selector) {
    const elements = await this.page.$$(selector);
    return elements.length;
  }

  // ============================================================================
  // Element Evaluation and Properties
  // ============================================================================

  async evaluateOnElement(locatorOrElement, fn, args) {
    // Puppeteer accepts the element as first arg, then spread args
    if (args === undefined) {
      return await this.page.evaluate(fn, locatorOrElement);
    }
    return await this.page.evaluate(fn, locatorOrElement, args);
  }

  async getTextContent(locatorOrElement) {
    return await this.page.evaluate((el) => el.textContent, locatorOrElement);
  }

  async getInnerText(locatorOrElement) {
    return await this.page.evaluate((el) => el.innerText, locatorOrElement);
  }

  async getInputValue(locatorOrElement) {
    return await this.page.evaluate((el) => el.value, locatorOrElement);
  }

  async getAttribute(locatorOrElement, attribute) {
    return await this.page.evaluate(
      (el, attr) => el.getAttribute(attr),
      locatorOrElement,
      attribute
    );
  }

  // ============================================================================
  // Element Interactions
  // ============================================================================

  async click(locatorOrElement, options = {}) {
    await locatorOrElement.click(options);
  }

  async type(locatorOrElement, text) {
    // Puppeteer requires focus before typing
    await locatorOrElement.focus();
    await this.page.keyboard.type(text);
  }

  async fill(locatorOrElement, text) {
    // Puppeteer doesn't have fill() - use evaluate to set value
    await this.page.evaluate(
      (el, value) => {
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      },
      locatorOrElement,
      text
    );
  }

  async focus(locatorOrElement) {
    await locatorOrElement.focus();
  }

  // ============================================================================
  // Page-level Keyboard Operations
  // ============================================================================

  async keyboardPress(key) {
    await this.page.keyboard.press(key);
  }

  async keyboardType(text) {
    await this.page.keyboard.type(text);
  }

  async keyboardDown(key) {
    await this.page.keyboard.down(key);
  }

  async keyboardUp(key) {
    await this.page.keyboard.up(key);
  }

  // ============================================================================
  // Page-level Operations
  // ============================================================================

  async evaluateOnPage(fn, args = []) {
    // Puppeteer accepts spread arguments
    return await this.page.evaluate(fn, ...args);
  }

  async getPageContent() {
    return await this.page.content();
  }

  getMainFrame() {
    return this.page.mainFrame();
  }

  async pdf(options = {}) {
    return await this.page.pdf(options);
  }
}

/**
 * Factory function to create appropriate adapter
 * @param {Object} page - Playwright or Puppeteer page object
 * @param {string} engine - Engine type ('playwright' or 'puppeteer')
 * @returns {EngineAdapter} - Appropriate adapter instance
 */
export function createEngineAdapter(page, engine) {
  if (!page) {
    const errorDetails = {
      page,
      pageType: typeof page,
      engine,
      stackTrace: new Error().stack,
    };
    throw new Error(
      `page is required in createEngineAdapter. Received: page=${page} (type: ${typeof page}), engine=${engine}. This may indicate that the page object was not properly passed through the function call chain. Stack trace: ${errorDetails.stackTrace}`
    );
  }

  if (engine === 'playwright') {
    return new PlaywrightAdapter(page);
  } else if (engine === 'puppeteer') {
    return new PuppeteerAdapter(page);
  } else if (engine === 'selenium') {
    return new SeleniumAdapter(page);
  } else {
    throw new Error(
      `Unsupported engine: ${engine}. Expected 'playwright', 'puppeteer' or 'selenium'`
    );
  }
}

/**
 * Selenium (WebDriver) adapter implementation (issue #104).
 *
 * The page is a `WebDriverPage` facade, which already speaks the Puppeteer
 * page API, so everything not listed here is the Puppeteer implementation.
 * The overrides use WebDriver's native element commands where they exist:
 * Element Click, Element Send Keys and Element Clear run the browser's own
 * interactability checks and produce trusted input events.
 */
export class SeleniumAdapter extends PuppeteerAdapter {
  getEngineName() {
    return 'selenium';
  }

  async click(locatorOrElement, options = {}) {
    if (options.force) {
      // Element Click refuses an obscured element; force means "click where
      // it is anyway", which is a pointer action at the element's centre.
      await this.page.evaluate(
        (el) => el.scrollIntoView({ block: 'center', inline: 'center' }),
        locatorOrElement
      );
      await this.page.driver
        .actions({ async: true })
        .move({ origin: locatorOrElement })
        .click()
        .perform();
    } else {
      await locatorOrElement.click();
    }
    // A click may navigate; page.url() should say where it went.
    await this.page.syncUrl();
  }

  async type(locatorOrElement, text) {
    await locatorOrElement.sendKeys(text);
  }

  async fill(locatorOrElement, text) {
    await locatorOrElement.clear();
    await locatorOrElement.sendKeys(text);
  }

  async focus(locatorOrElement) {
    await this.page.evaluate((el) => el.focus(), locatorOrElement);
  }

  // ============================================================================
  // WebDriver and BiDi access
  // ============================================================================

  /** @returns {Object} The selenium-webdriver WebDriver */
  getDriver() {
    return this.page.driver;
  }

  /** @returns {Promise<Object|null>} The BiDi connection, null for classic */
  getBidi() {
    return this.page.bidi();
  }

  /**
   * Subscribe to a raw BiDi event, e.g. 'log.entryAdded'.
   * @returns {Promise<{unsubscribe: Function}>}
   */
  onBidiEvent(method, handler) {
    return this.page.subscribeBidi(method, handler);
  }

  /**
   * Receive console messages (BiDi `log.entryAdded`).
   * @param {Function} handler - Receives a Puppeteer-shaped ConsoleMessage
   * @returns {Promise<Function>} Resolves once subscribed, to an unsubscribe
   */
  onConsoleMessage(handler) {
    return this._listen('console', handler);
  }

  /**
   * Receive top-level navigations (BiDi browsingContext events).
   * @param {Function} handler - Receives the new URL
   * @returns {Promise<Function>} Resolves once subscribed, to an unsubscribe
   */
  onNavigation(handler) {
    return this._listen('framenavigated', (frame) => handler(frame.url()));
  }

  async _listen(eventName, handler) {
    await this.page.requireBidi(`page "${eventName}" events`);
    this.page.on(eventName, handler);
    await this.page.eventsReady();
    return () => this.page.off(eventName, handler);
  }

  /**
   * Navigate with BiDi `browsingContext.navigate`.
   * @param {string} url
   * @param {Object} [options] - {wait: 'none'|'interactive'|'complete'}
   */
  navigate(url, options = {}) {
    return this.page.navigateBidi(url, options);
  }
}
