/**
 * Browser Commander - Factory Function
 * This module provides the makeBrowserCommander factory function that creates
 * a browser commander instance with all bound methods.
 */

import { createLogger } from './core/logger.js';
import { detectEngine } from './core/engine-detection.js';
import { WebDriverPage } from './core/webdriver-page.js';
import { createNetworkTracker } from './core/network-tracker.js';
import { createNavigationManager } from './core/navigation-manager.js';
import { createPageSessionFactory } from './core/page-session.js';
import { createDialogManager } from './core/dialog-manager.js';
import {
  createPageTriggerManager,
  ActionStoppedError,
  isActionStoppedError,
  makeUrlCondition,
  allConditions,
  anyCondition,
  notCondition,
} from './core/page-trigger-manager.js';
import { createBoundFunctions } from './bindings.js';
import { attachDownloads } from './downloads/attach.js';
import { attachCommanderFeatures } from './core/commander-features.js';
import { createCdpSession } from './browser/cdp-session.js';

/**
 * Create a browser commander instance for a specific page
 * @param {Object} options - Configuration options
 * @param {Object} options.page - Playwright or Puppeteer page object, or a selenium-webdriver WebDriver (or the WebDriverPage launchWebDriver() returns)
 * @param {boolean} options.verbose - Enable verbose logging
 * @param {boolean} options.enableNetworkTracking - Enable network request tracking (default: true)
 * @param {boolean} options.enableNavigationManager - Enable navigation manager (default: true)
 * @param {Object} [options.downloads] - A download manager to expose as commander.downloads, such as the one launchBrowser() returned
 * @param {boolean|Object} [options.debug=false] - Opt-in recording: true, {output}, or {directory, retain, maxDurationMs, limits} for managed storage
 * @returns {Object} - Browser commander API
 */
export function makeBrowserCommander(options = {}) {
  const {
    page: providedPage,
    verbose = false,
    enableNetworkTracking = true,
    enableNavigationManager = true,
    enableDialogManager = true,
    downloads = null,
  } = options;

  if (!providedPage) {
    throw new Error('page is required in options');
  }

  const engine = detectEngine(providedPage);
  // A bare selenium-webdriver WebDriver is wrapped in the page facade the
  // helpers speak to (issue #104); launchWebDriver() already returns one.
  const page =
    engine === 'selenium' && !providedPage.isWebDriverPage
      ? new WebDriverPage(providedPage)
      : providedPage;
  const log = createLogger({ verbose });

  // Create NetworkTracker if enabled
  // Use 30 second idle timeout to ensure page is fully loaded
  let networkTracker = null;
  if (enableNetworkTracking) {
    networkTracker = createNetworkTracker({
      page,
      engine,
      log,
      idleTimeout: options.networkIdleForMs ?? 30000, // Wait 30 seconds without requests before considering network idle
    });
    networkTracker.startTracking();
  }

  // Create NavigationManager if enabled
  let navigationManager = null;
  let sessionFactory = null;

  // Create DialogManager if enabled
  let dialogManager = null;
  if (enableDialogManager) {
    dialogManager = createDialogManager({ page, engine, log });
    dialogManager.startListening();
  }

  // PageTriggerManager (will be initialized after commander is created)
  let pageTriggerManager = null;

  if (enableNavigationManager) {
    navigationManager = createNavigationManager({
      page,
      engine,
      log,
      networkTracker,
    });
    navigationManager.configure(navigationOptions(options));
    navigationManager.startListening();

    // Create PageSession factory
    sessionFactory = createPageSessionFactory({
      navigationManager,
      networkTracker,
      log,
    });

    // Create PageTriggerManager
    pageTriggerManager = createPageTriggerManager({
      navigationManager,
      log,
    });
  }

  // Create all bound functions
  const boundFunctions = createBoundFunctions({
    page,
    engine,
    log,
    verbose,
    navigationManager,
    networkTracker,
  });

  // Cleanup function
  const destroy = async () => {
    // Downloads are disposed first: disposing waits for bytes still being
    // written, and a caller that destroys the commander right after a click
    // should still find the file.
    if (commander.downloads) {
      await commander.downloads.dispose();
    }
    if (pageTriggerManager) {
      await pageTriggerManager.destroy();
    }
    if (networkTracker) {
      networkTracker.stopTracking();
    }
    if (navigationManager) {
      navigationManager.stopListening();
    }
    if (sessionFactory) {
      await sessionFactory.endAllSessions();
    }
    if (dialogManager) {
      dialogManager.stopListening();
    }
  };

  // Build commander object
  const commander = {
    // Core properties
    engine,
    page,
    log,

    // Navigation management components
    networkTracker,
    navigationManager,
    sessionFactory,
    pageTriggerManager,
    dialogManager,

    // All bound functions
    ...boundFunctions,
    // Managed downloads (issue #88). Present once a manager is attached,
    // either by passing the one launchBrowser() returned or by calling
    // configureDownloads() on an existing commander.
    downloads,

    /**
     * Attach a managed download lifecycle to this commander's browser.
     *
     * @param {boolean|Object} [downloadOptions=true] - true for defaults, or {directory, persist, conflict}
     * @returns {Promise<Object>} The attached download manager
     */
    configureDownloads: async (downloadOptions = true) => {
      // Replacing a manager detaches the old one rather than leaving two
      // sources writing into the same directory.
      await commander.downloads?.dispose();
      commander.downloads = await attachDownloads({
        engine,
        browser: page.context?.() ?? page.browser?.(),
        page,
        downloads: downloadOptions,
        log,
      });
      return commander.downloads;
    },

    /**
     * Open a raw CDP session for this commander's page (issue #104).
     *
     * @returns {Promise<Object>} {send, on, once, off, detach, session, engine}
     */
    createCdpSession: () => createCdpSession(page, { engine }),

    // Lifecycle
    destroy,

    // Convenience methods for page sessions (legacy API)
    createSession: sessionFactory
      ? (opts) => sessionFactory.createSession(opts)
      : null,
    getActiveSessions: sessionFactory
      ? () => sessionFactory.getActiveSessions()
      : () => [],

    // Subscribe to navigation events (legacy API)
    onNavigationStart: navigationManager
      ? (fn) => navigationManager.on('onNavigationStart', fn)
      : () => () => {},
    onNavigationComplete: navigationManager
      ? (fn) => navigationManager.on('onNavigationComplete', fn)
      : () => () => {},
    onUrlChange: navigationManager
      ? (fn) => navigationManager.on('onUrlChange', fn)
      : () => () => {},
    onPageReady: navigationManager
      ? (fn) => navigationManager.on('onPageReady', fn)
      : () => () => {},

    // Abort handling - check these to stop operations when navigation occurs
    shouldAbort: navigationManager
      ? () => navigationManager.shouldAbort()
      : () => false,
    getAbortSignal: navigationManager
      ? () => navigationManager.getAbortSignal()
      : () => null,

    // Page Trigger API
    // Register a trigger: commander.pageTrigger({ condition, action, name })
    // condition receives context: { url, commander }
    // action receives context: { url, commander, checkStopped, forEach, wait, onCleanup, ... }
    pageTrigger: pageTriggerManager
      ? (config) => pageTriggerManager.pageTrigger(config)
      : () => {
          throw new Error('pageTrigger requires enableNavigationManager: true');
        },

    // Dialog event handling API
    // Register a handler: commander.onDialog(async (dialog) => { await dialog.dismiss(); })
    // dialog.type()     → 'alert' | 'confirm' | 'prompt' | 'beforeunload'
    // dialog.message()  → The dialog message text
    // dialog.accept(text?) → Accept/confirm (optional text for prompts)
    // dialog.dismiss()  → Dismiss/cancel the dialog
    onDialog: dialogManager
      ? (fn) => dialogManager.onDialog(fn)
      : () => {
          throw new Error('onDialog requires enableDialogManager: true');
        },
    offDialog: dialogManager
      ? (fn) => dialogManager.offDialog(fn)
      : () => {
          throw new Error('offDialog requires enableDialogManager: true');
        },
    clearDialogHandlers: dialogManager
      ? () => dialogManager.clearDialogHandlers()
      : () => {
          throw new Error(
            'clearDialogHandlers requires enableDialogManager: true'
          );
        },

    // Watch dialogs without answering them (issue #87): an observer is told
    // about every dialog and never suppresses the manager's auto-dismissal.
    observeDialogs: dialogManager
      ? (fn) => dialogManager.observeDialogs(fn)
      : () => {
          throw new Error('observeDialogs requires enableDialogManager: true');
        },
    unobserveDialogs: dialogManager
      ? (fn) => dialogManager.unobserveDialogs(fn)
      : () => {},

    // URL condition helpers
    makeUrlCondition,
    allConditions,
    anyCondition,
    notCondition,

    // Error classes for action control flow
    ActionStoppedError,
    isActionStoppedError,
  };

  // Initialize PageTriggerManager with the commander
  if (pageTriggerManager) {
    pageTriggerManager.initialize(commander);
  }

  attachCommanderFeatures(commander, options, makeBrowserCommander);
  return commander;
}

function navigationOptions(options) {
  return {
    ...(options.navigationManager ?? {}),
    ...(options.networkIdleTimeout === undefined
      ? {}
      : { networkIdleTimeout: options.networkIdleTimeout }),
  };
}
