#!/usr/bin/env node

/**
 * Create GitHub Release from CHANGELOG.md
 * Usage: node scripts/create-github-release.mjs --release-version <version> --repository <repository>
 *   release-version: Version number (e.g., 1.0.0)
 *   repository: GitHub repository (e.g., owner/repo)
 *
 * Uses link-foundation libraries:
 * - use-m: Dynamic package loading without package.json dependencies
 * - command-stream: Modern shell command execution with streaming support
 * - lino-arguments: Unified configuration from CLI args, env vars, and .lenv files
 */

import { readFileSync } from 'fs';

import { releaseTag } from '../../scripts/release-tags.mjs';
import {
  commandErrorText,
  loadCommandStream,
  loadLinoArguments,
} from '../../scripts/use-module.mjs';

const { $ } = await loadCommandStream();
const { makeConfig } = await loadLinoArguments();

// Parse CLI arguments using lino-arguments
// Note: Using --release-version instead of --version to avoid conflict with yargs' built-in --version flag
const config = makeConfig({
  yargs: ({ yargs, getenv }) =>
    yargs
      .option('release-version', {
        type: 'string',
        default: getenv('VERSION', ''),
        describe: 'Version number (e.g., 1.0.0)',
      })
      .option('repository', {
        type: 'string',
        default: getenv('REPOSITORY', ''),
        describe: 'GitHub repository (e.g., owner/repo)',
      }),
});

const { releaseVersion: version, repository } = config;

if (!version || !repository) {
  console.error('Error: Missing required arguments');
  console.error(
    'Usage: node scripts/create-github-release.mjs --release-version <version> --repository <repository>'
  );
  process.exit(1);
}

// `v<version>` is this package's namespace only; the crate uses `rust-v` and
// the wheel `python-v`. See scripts/release-tags.mjs.
const tag = releaseTag('js', version);

console.log(`Creating GitHub release for ${tag}...`);

try {
  // Read CHANGELOG.md
  const changelog = readFileSync('./CHANGELOG.md', 'utf8');

  // Extract changelog entry for this version
  // Read from CHANGELOG.md between this version header and the next version header
  const versionHeaderRegex = new RegExp(`## ${version}[\\s\\S]*?(?=## \\d|$)`);
  const match = changelog.match(versionHeaderRegex);

  let releaseNotes = '';
  if (match) {
    // Remove the version header itself and trim
    releaseNotes = match[0].replace(`## ${version}`, '').trim();
  }

  // Falling back to a bare "Release <version>" body is a silent downgrade:
  // the release still goes out and the job still passes, so this annotation is
  // what makes an empty release body visible in the run summary.
  if (!releaseNotes) {
    console.warn(
      `::warning::Version ${version} has no "## ${version}" section in ` +
        'CHANGELOG.md, releasing without notes'
    );
    releaseNotes = `Release ${version}`;
  }

  // Create release using GitHub API with JSON input
  // This avoids shell escaping issues that occur when passing text via command-line arguments
  // (Previously caused apostrophes like "didn't" to appear as "didn'''" in releases)
  const payload = JSON.stringify({
    tag_name: tag,
    name: version,
    body: releaseNotes,
  });

  try {
    await $`gh api repos/${repository}/releases -X POST --input -`.run({
      stdin: payload,
    });
    console.log(`\u2705 Created GitHub release: ${tag}`);
  } catch (error) {
    // Re-running a release over a tag that already has one is not a failure.
    // The rust script has always tolerated it; the JS one did not need to
    // while a failed `gh` call resolved instead of rejecting.
    if (commandErrorText(error).includes('already exists')) {
      console.log(`Release ${tag} already exists, skipping`);
    } else {
      throw error;
    }
  }
} catch (error) {
  console.error('Error creating release:', error.message);
  process.exit(1);
}
