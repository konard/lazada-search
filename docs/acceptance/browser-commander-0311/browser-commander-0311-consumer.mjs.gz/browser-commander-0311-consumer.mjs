import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile } from 'node:fs/promises';
import { Link, Parser, StreamParser } from 'links-notation';
import { traceLinks, formatTraceLinks, decodeLinkText } from 'browser-commander';
const require = createRequire(import.meta.url);
const commanderRequire = createRequire(require.resolve('browser-commander'));
assert.equal(require.resolve('links-notation'), commanderRequire.resolve('links-notation'));
const lock = JSON.parse(await readFile('package-lock.json', 'utf8'));
assert.deepEqual(Object.entries(lock.packages).filter(([name]) => name === 'node_modules/links-notation' || name === 'node_modules/browser-commander/node_modules/links-notation').map(([path, entry]) => ({ path, version: entry.version })), [{ path: 'node_modules/links-notation', version: '0.25.2' }]);
const texts = ['Socola; Không Bình; sữa đạm', '', 'both "double" and \'single\'', '~1{61}', 'row\r\nwith\ttab and\\slash', '\u0000\u0001\u007f', '\u2028\u2029\ufeff', '\ud800', '\udfff', '🧭\ud800日本語\udfff'];
for (const text of texts) {
  const [record] = await traceLinks({ path: 'local-consumer', manifest: {schemaVersion: 1}, events: [{kind: 'console', text}], network: [] }, {include: ['timeline']});
  assert.ok(record instanceof Link);
  const notation = formatTraceLinks([record]);
  const parsed = new Parser().parse(notation);
  const field = parsed[0].values.find((value) => value.id === 'text');
  assert.equal(decodeLinkText(field.values[0].id), text);
  for (const size of [1, 17, notation.length]) {
    const stream = new StreamParser();
    for (let offset = 0; offset < notation.length; offset += size) stream.write(notation.slice(offset, offset + size));
    stream.end();
    assert.deepEqual(stream.drain(), parsed);
  }
}
console.log(JSON.stringify({ browserCommander: lock.packages['node_modules/browser-commander'].version, notation: '0.25.2', sharedModuleAndLinkClass: true, exactScalarCases: texts.length, streamingChunkSizes: [1, 17, 'entire'], originalMarketplaceDownloads: 0 }));
