# Source-pixel OCR compatibility experiment

Completed only in this isolated directory. The repository, source image, browser, accounts and shared associative stores were not changed. No product/nutrition facts were approved; exact Lazada identity remains unmatched.

Original manufacturer image: SHA-256 `67907ce23aa9ff33a8431ad6ebe68289d842ab83f14586abf9d5ac7a5ab3c9e8`. `generate.mjs` preserves its bytes as `original.png` and derives bounded PNG crops with Sharp. Source rectangles and grayscale are unchanged from the preserved decimal-ocr recipe.

The matching official Ubuntu 24.04 amd64 container uses Tesseract 5.3.4, Ubuntu `tesseract-ocr` package `5.3.4-1build5`, and English package `1:4.1.0-2`. Local macOS uses Tesseract 5.5.2. Both English model files hash to `7d4322bd2a7749724879683fc3912cb542f19906c83bcc1a52132556427170b2`. Docker image digest, complete versions and renderer fingerprints are in `winning-review.json` and `experiment.json`.

All forty actual OCR calls use the same unwhitelisted command:

```sh
tesseract CROP.png stdout -l eng --psm 7 -c tessedit_create_tsv=1
```

There is no replacement of recognized numbers, whitelist or expected-value constraint. Original TSV output is retained separately for both engines. Twenty pixel transforms per engine preserve negative controls: 2x Lanczos3 produces `45` on Ubuntu and `4.5` on macOS. Larger scales can corrupt the final digit into punctuation. The two 2x nearest-neighbour crops produce literal `4.5` and `4.0` on both engines.

| Basis | Crop | Resize | Derived PNG SHA-256 |
| --- | --- | --- | --- |
| per100g | left801 top517 width82 height68 | 164x136 nearest | `6c81406db64dc7beae7f505b4187fa1fe9647e56bf6720f076088fce2491dff7` |
| per100ml | left1074 top512 width83 height73 | 166x146 nearest | `f9e0b534387a2845997eeddb3835cf423ed40caf414a9fe5bb229e8b01bbcb10` |

Minimal proposed test-only diff in the final native test of `tests/ocr-crops.test.js`:

```diff
 const per100g = await ocr.recognize(blob, {
   psm: 7,
-  transform: transform(),
+  transform: transform({
+    resize: { width: 164, height: 136, kernel: 'nearest' },
+  }),
   sourceOcrId: baseline.id,
 });
 ...
- resize: { width: 166, height: 146 },
+ resize: { width: 166, height: 146, kernel: 'nearest' },
```

Keep the historical Lanczos3 baseline and mocked/cached tests unchanged. The library already validates and fingerprints `nearest` transforms, including original source bytes, exact crop, physical derived bytes, renderer versions, engine version and OCR provenance. Source text remains authoritative; OCR still requires review and exact market/package/formula identity before approval.

Future automation should treat materially different raw readings under valid pixel recipes as a review conflict, retain every original/derived image and TSV, and test engine compatibility with actual source pixels. This experiment proves the two tested engines and public label, not arbitrary images or every engine version. Windows 5.5.3 still requires its actual CI receipt for the revised recipe. A separate cache identity consideration is a traineddata replacement under an unchanged engine/version/language/path; model digests are recorded here but the current library cache does not fingerprint model bytes.
