import sharp from '/Users/konard/Code/Archive/konard/lazada-search/node_modules/sharp/dist/index.cjs';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
const run = promisify(execFile);
const directory = '/private/tmp/lazada-ocr-ubuntu-experiment';
const original = await readFile('/Users/konard/Code/Archive/konard/lazada-search/docs/acceptance/ice-dual-units/expanded-hd-sg-belgian-label.png');
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex');
await writeFile(`${directory}/original.png`, original);
const regions = [
  { basis: 'per100g', crop: { left: 801, top: 517, width: 82, height: 68 } },
  { basis: 'per100ml', crop: { left: 1074, top: 512, width: 83, height: 73 } },
];
const variants = [
  { scale: 1, kernel: 'nearest', grayscale: true },
  ...[2,3,4,6].flatMap(scale => ['lanczos3','nearest'].map(kernel => ({scale,kernel,grayscale:true}))),
  { scale: 4, kernel: 'nearest', grayscale: false },
];
const rows = [];
for (const region of regions) for (const variant of variants) {
  const resize = { width: region.crop.width*variant.scale, height: region.crop.height*variant.scale, kernel: variant.kernel };
  let image = sharp(original).extract(region.crop).flatten({background:'#ffffff'});
  if (variant.grayscale) image = image.grayscale();
  const bytes = await image.resize({...resize,fit:'fill'}).png({compressionLevel:9,adaptiveFiltering:false,palette:false}).toBuffer();
  const name = `${region.basis}-${variant.scale}x-${variant.kernel}-${variant.grayscale?'gray':'rgb'}`;
  await writeFile(`${directory}/${name}.png`,bytes);
  const args = [`${directory}/${name}.png`,'stdout','-l','eng','--psm','7','-c','tessedit_create_tsv=1'];
  const {stdout} = await run('tesseract',args);
  await writeFile(`${directory}/${name}.mac.tsv`,stdout);
  const words=stdout.trim().split('\n').slice(1).map(line=>line.split('\t')).filter(line=>Number(line[10])>=0&&line[11]);
  rows.push({name,basis:region.basis,transform:{crop:region.crop,resize,grayscale:variant.grayscale},imageSha256:digest(bytes),imageBytes:bytes.length,mac:{command:['tesseract',...args],tsvSha256:digest(stdout),text:words.map(line=>line[11]).join(' '),confidence:words.map(line=>Number(line[10]))}});
}
const receipt={observedAt:new Date().toISOString(),originalSha256:digest(original),renderer:sharp.versions,macVersion:(await run('tesseract',['--version'])).stdout,rows};
await writeFile(`${directory}/experiment.json`,JSON.stringify(receipt,null,2)+'\n');
for (const row of rows) console.log(row.name,JSON.stringify(row.mac.text));
