import test from 'node:test';
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { runCommand } from './node_modules/browser-commander/src/utilities/subprocess.js';
const run = promisify(execFile);
test('Browser Commander missing executable preserves the baseline 127 and ENOENT detail', async () => {
  await assert.rejects(runCommand('/no-such-fixture-executable'), (error) => error.code === 127 && error.stderr.includes('ENOENT'));
});
test('Browser Commander detached child survives its launcher without keeping launcher alive', async () => {
  const marker = join(process.cwd(), 'detached-marker.json');
  const launcher = join(process.cwd(), 'detached-launcher.mjs');
  await rm(marker, { force: true });
  const code = 'setTimeout(()=>{require("node:fs").writeFileSync(process.argv[1],JSON.stringify({alive:true}));},250);';
  const moduleText = 'import {startDetachedProcess} from "./node_modules/browser-commander/src/utilities/subprocess.js";await startDetachedProcess(process.execPath,' + JSON.stringify(['-e', code, marker]) + ');';
  await writeFile(launcher, moduleText);
  const started = Date.now();
  await run(process.execPath, [launcher], { timeout: 5000 });
  assert.ok(Date.now() - started < 2000, 'launcher must release process handles');
  for (let attempt = 0; attempt < 40; attempt++) {
    try {
      assert.equal(JSON.parse(await readFile(marker, 'utf8')).alive, true);
      return;
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  assert.fail('detached child did not survive launcher exit');
});
